export class DataService {
  
    presenceTab = [
        {
            name: "Emmanuelle",
            status: "Présent"
        },
        {
            name: "Robin",
            status: "Absent"
        },
        {
            name: "Dominique",
            status: "Présent"
        }
    ];

}